typedef unsigned int u32;
int printd(int x) ;
int printx(u32 x) ;
int printo(u32 x) ;
void myprintf(char *fmt, ...);